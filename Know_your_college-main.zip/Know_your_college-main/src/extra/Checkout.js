import React from 'react'
import ramu from '../img/5.png';
import './checkout.css'

export default function Checkout() {
        return (
                <div style={{ "background-image":`url(${ramu})`, "background-repeat": "no-repeat",
                "background-size" : "cover",minHeight:'100vh' }}  className='kar'>
                        
                </div>
                 
                 
        )
}
