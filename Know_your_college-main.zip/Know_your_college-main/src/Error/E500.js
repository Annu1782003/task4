import React from 'react'

export default function E500() {
        return (
                <div>
                        <h1>505</h1>
                </div>
        )
}
