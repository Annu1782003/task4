import React, { useEffect } from 'react'
import { Container } from 'react-bootstrap'
import Navbar from '../../extra/Navbar'
import Footer from '../../extra/Footer'
import Landingpage from './Landingpage'


export default function Second() {

        return (
                <div  >

                        <Landingpage />
                        <Footer />

                </div>
        )
}
